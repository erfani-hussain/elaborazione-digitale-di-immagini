function canale_rosso (vecchi_pixels, nuovi_pixels, larghezza_immagine, altezza_immagine) {
  
}