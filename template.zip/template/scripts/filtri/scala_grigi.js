function scala_grigi (vecchi_pixels, nuovi_pixels, larghezza_immagine, altezza_immagine) {
  
}