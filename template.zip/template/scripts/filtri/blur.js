function blur (vecchi_pixels, nuovi_pixels, larghezza_immagine, altezza_immagine) {
   
}