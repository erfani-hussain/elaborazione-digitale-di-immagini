function mio_filtro_3 (vecchi_pixels, nuovi_pixels, larghezza_immagine, altezza_immagine) {
   
}