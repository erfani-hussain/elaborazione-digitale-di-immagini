function mio_filtro_2 (vecchi_pixels, nuovi_pixels, larghezza_immagine, altezza_immagine) {
   
}